<template>
  <div class="performance-analysis-container">
    <router-view></router-view>
  </div>
</template>

<script>
export default {
  name: 'PerformanceAnalysis'
}
</script>

<style scoped>
.performance-analysis-container {
  width: 100%;
  height: 100%;
}
</style> 