<template>
  <div class="performance-dashboard-container">
    <!-- Empty Performance Dashboard page -->
  </div>
</template>

<script>
export default {
  name: 'PerformanceDashboard',
  data() {
    return {
      // Empty data
    }
  }
}
</script>

<style scoped>
.performance-dashboard-container {
  margin-left: 180px;
  padding: 32px 24px 24px 24px;
  background: #f8f9fb;
  min-height: 100vh;
  font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
}
</style> 